<section class="gallery pt-100 pb-90">
    <div class="container">

        <div class="row mt-50 mb-50">
            <div class="col-12">
                <h2>The Everlasting Scenes
                </h2>
            </div>
            <div class="col-lg-6 col-sm-12 col-md-12">
                <div class="member">
                    <video class="video-player-covid-support" controls>
                        <!-- <video width="320" height="240" controls> -->
                        <source src="./assets/videos/mov_bbb.mp4" type="video/mp4">

                    </video>
                    <div class="member__info">
                        <h5 class="member__name"><a href="doctors-single-doctor1.html">Dr Asim Patel</a></h5>
                        <p class="member__job">9.00 am to 9.00 pm </p>
                    </div>
                    <!-- /.member-info -->
                </div><!-- /.member -->
                <div class="member">
                    <video class="video-player-covid-support" controls>
                        <!-- <video width="320" height="240" controls> -->
                        <source src="./assets/videos/mov_bbb.mp4" type="video/mp4">

                    </video>
                    <div class="member__info">
                        <h5 class="member__name"><a href="doctors-single-doctor1.html">Dr Asim Patel</a></h5>
                        <p class="member__job">9.00 am to 9.00 pm </p>
                    </div>
                    <!-- /.member-info -->
                </div><!-- /.member -->
                <div class="member">
                    <video class="video-player-covid-support" controls>
                        <!-- <video width="320" height="240" controls> -->
                        <source src="./assets/videos/mov_bbb.mp4" type="video/mp4">

                    </video>
                    <div class="member__info">
                        <h5 class="member__name"><a href="doctors-single-doctor1.html">Dr Asim Patel</a></h5>
                        <p class="member__job">9.00 am to 9.00 pm </p>
                    </div>
                    <!-- /.member-info -->
                </div><!-- /.member -->
            </div>
            <div class="col-lg-6 col-sm-12 col-md-12">
                <div class="member">
                    <video class="video-player-covid-support" controls>
                        <!-- <video width="320" height="240" controls> -->
                        <source src="./assets/videos/mov_bbb.mp4" type="video/mp4">

                    </video>
                    <div class="member__info">
                        <h5 class="member__name"><a href="doctors-single-doctor1.html">Dr Asim Patel</a></h5>
                        <p class="member__job">9.00 am to 9.00 pm </p>
                    </div>
                    <!-- /.member-info -->
                </div><!-- /.member -->
                <div class="member">
                    <video class="video-player-covid-support" controls>
                        <!-- <video width="320" height="240" controls> -->
                        <source src="./assets/videos/mov_bbb.mp4" type="video/mp4">

                    </video>
                    <div class="member__info">
                        <h5 class="member__name"><a href="doctors-single-doctor1.html">Dr Asim Patel</a></h5>
                        <p class="member__job">9.00 am to 9.00 pm </p>
                    </div>
                    <!-- /.member-info -->
                </div><!-- /.member -->
                <div class="member">
                    <video class="video-player-covid-support" controls>
                        <!-- <video width="320" height="240" controls> -->
                        <source src="./assets/videos/mov_bbb.mp4" type="video/mp4">

                    </video>
                    <div class="member__info">
                        <h5 class="member__name"><a href="doctors-single-doctor1.html">Dr Asim Patel</a></h5>
                        <p class="member__job">9.00 am to 9.00 pm </p>
                    </div>
                    <!-- /.member-info -->
                </div><!-- /.member -->
            </div>
        </div>
    </div><!-- /.container -->
</section><!-- /.gallery 2 -->